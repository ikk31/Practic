﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace MP3
{
    class Program
    {
        static readonly string[] genres = new[] {
        "Pop","Rock","Hip-Hop","Jazz","Classical","Electronic","Dance","Metal",
        "Country","Reggae","Blues","Folk","R&B","Soul","Punk","Alternative",
        "Soundtrack","Instrumental","World","Other"
    };

        static string Clean(byte[] b, int off, int len, Encoding enc)
        {
            string s = enc.GetString(b, off, len).TrimEnd('\0', ' ');
            return s.Length == 0 ? "—" : s;
        }

        static void Main()
        {
            Console.Write("Путь к файлу (.mp3): ");
            string path = Console.ReadLine();
            if (string.IsNullOrWhiteSpace(path)) { Console.WriteLine("Путь не указан."); return; }
            path = path.Trim().Trim('"');
            Console.WriteLine("Файл: " + Path.GetFileName(path));
            if (!File.Exists(path)) { Console.WriteLine("Файл не найден."); return; }

            try
            {
                byte[] tag = new byte[128];
                using (FileStream fs = File.OpenRead(path))
                {
                    if (fs.Length < 128) { Console.WriteLine("ID3v1 теги не найдены."); return; }
                    fs.Seek(-128, SeekOrigin.End);
                    int read = fs.Read(tag, 0, 128);
                    if (read != 128 || tag[0] != (byte)'T' || tag[1] != (byte)'A' || tag[2] != (byte)'G')
                    {
                        Console.WriteLine("ID3v1 теги не найдены."); return;
                    }
                }

                Encoding enc;
                try
                {
                    enc = Encoding.GetEncoding("ISO-8859-1");
                }
                catch
                {
                    // Попытка зарегистрировать кодировки через reflection, если сборка доступна
                    try
                    {
                        var t = Type.GetType("System.Text.CodePagesEncodingProvider, System.Text.Encoding.CodePages");
                        if (t != null)
                        {
                            var inst = t.GetProperty("Instance", BindingFlags.Static | BindingFlags.Public).GetValue(null, null);
                            typeof(Encoding).GetMethod("RegisterProvider", BindingFlags.Static | BindingFlags.Public).Invoke(null, new object[] { inst });
                        }
                        enc = Encoding.GetEncoding("ISO-8859-1");
                    }
                    catch
                    {
                        enc = Encoding.Default;
                    }
                }

                string title = Clean(tag, 3, 30, enc);
                string artist = Clean(tag, 33, 30, enc);
                string album = Clean(tag, 63, 30, enc);
                string year = Clean(tag, 93, 4, enc);
                string genre = (tag[127] < genres.Length) ? genres[tag[127]] : ("Unknown (" + tag[127] + ")");

                Console.WriteLine("Название: " + title);
                Console.WriteLine("Исполнитель: " + artist);
                Console.WriteLine("Альбом: " + album);
                Console.WriteLine("Год: " + year);
                Console.WriteLine("Жанр: " + genre);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Ошибка: " + ex.Message);
            }
            Console.ReadKey();
        }
    }
}
//C:\Users\student\Desktop\Bon_Jovi_-_Its_My_Life_47852367.mp3