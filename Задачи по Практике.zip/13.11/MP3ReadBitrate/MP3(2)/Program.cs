﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MP3_2_
{
    class Program
    {
        static readonly int[] sr1 = { 44100, 48000, 32000 }, sr2 = { 22050, 24000, 16000 }, sr25 = { 11025, 12000, 8000 };
        static readonly int[] m1l1 = { 0, 32, 64, 96, 128, 160, 192, 224, 256, 288, 320, 352, 384, 416, 448, 0 };
        static readonly int[] m1l2 = { 0, 32, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320, 384, 0 };
        static readonly int[] m1l3 = { 0, 32, 40, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320, 0 };
        static readonly int[] m2l1 = { 0, 32, 48, 56, 64, 80, 96, 112, 128, 144, 160, 176, 192, 224, 256, 0 };
        static readonly int[] m2l2 = { 0, 8, 16, 24, 32, 40, 48, 56, 64, 80, 96, 112, 128, 144, 160, 0 };
        static readonly int[] m2l3 = { 0, 8, 16, 24, 32, 40, 48, 56, 64, 80, 96, 112, 128, 144, 160, 0 };

        static void Main()
        {
            Console.Write("Путь к файлу (.mp3): ");
            string path = Console.ReadLine()?.Trim().Trim('"');
            if (string.IsNullOrEmpty(path) || !File.Exists(path)) { Console.WriteLine("Файл не найден."); return; }

            using (var fs = File.OpenRead(path))
            {
                long fileLen = fs.Length;
                int skip = 0;
                byte[] buf = new byte[10];
                if (fs.Read(buf, 0, 10) == 10 && buf[0] == (byte)'I' && buf[1] == (byte)'D' && buf[2] == (byte)'3')
                {
                    int sz = (buf[6] & 0x7F) << 21 | (buf[7] & 0x7F) << 14 | (buf[8] & 0x7F) << 7 | (buf[9] & 0x7F);
                    skip = 10 + sz;
                }
                fs.Seek(skip, SeekOrigin.Begin);
                byte[] h = new byte[4];
                if (fs.Read(h, 0, 4) != 4) { Console.WriteLine("Не удалось прочитать заголовок."); return; }

                uint H = (uint)(h[0] << 24 | h[1] << 16 | h[2] << 8 | h[3]);
                if (((H >> 21) & 0x7FF) != 0x7FF) { Console.WriteLine("MP3 заголовок не найден."); return; }

                int ver = (int)((H >> 19) & 3), layer = (int)((H >> 17) & 3), brIdx = (int)((H >> 12) & 0xF), srIdx = (int)((H >> 10) & 3);
                int[] sr = ver == 3 ? sr1 : ver == 2 ? sr2 : sr25;
                if (srIdx >= 3) { Console.WriteLine("Частота не определена."); return; }

                int br = 0;
                if (layer == 3) br = (ver == 3) ? m1l1[brIdx] : m2l1[brIdx];
                else if (layer == 2) br = (ver == 3) ? m1l2[brIdx] : m2l2[brIdx];
                else if (layer == 1) br = (ver == 3) ? m1l3[brIdx] : m2l3[brIdx];
                else { Console.WriteLine("Ошибка."); return; }

                if (br == 0) { Console.WriteLine("Битрейт не определён."); return; }
                int sampleRate = sr[srIdx];
                double durSec = (fileLen * 8.0) / (br * 1000.0);
                int t = (int)Math.Round(durSec);
                Console.WriteLine("Файл: " + Path.GetFileName(path));
                Console.WriteLine("Битрейт: " + br + " kbps");
                Console.WriteLine("Частота: " + sampleRate + " Гц");
                Console.WriteLine("Длительность: " + (t / 60) + ":" + (t % 60).ToString("D2"));
            }
            Console.ReadKey();
            Console.ReadKey();
        }
    }
}
//C:\Users\student\Desktop\Bon_Jovi_-_Its_My_Life_47852367.mp3
