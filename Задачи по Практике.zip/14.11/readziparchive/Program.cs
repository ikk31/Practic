﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO.Compression;

namespace readziparchive
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = Encoding.Unicode;
            Console.InputEncoding = Encoding.Unicode;
            Console.WriteLine("Введите путь до zip архива");
            string path = Console.ReadLine();
            if (!File.Exists(path))
            {
                Console.WriteLine("файл не найден");
                return;
            }

            try
            {
                using (var archive = ZipFile.OpenRead(path))
                {
                    Console.WriteLine($"Содержимое архива: {Path.GetFileName(path)}");
                    int index = 0;
                    foreach (var entry in archive.Entries)
                    {
                        
                        string type = Path.GetExtension(entry.FullName);
                        byte[] name = Encoding.Unicode.GetBytes(entry.FullName + "\0");


                        Console.WriteLine($"Индекс: {index}");
                        Console.WriteLine($"Имя файла: {Encoding.Unicode.GetString(name)}");
                        if (type == string.Empty)
                        {
                            Console.WriteLine($"Тип файла: Папка");
                        }
                        else
                        {
                            Console.WriteLine($"Тип файла: {type}");
                        }
                        Console.WriteLine($"Размер: {entry.Length}");
                        Console.WriteLine($"Сжатый размер: {entry.CompressedLength}");
                        Console.WriteLine($"Время последней модификации: {entry.LastWriteTime}");
                        Console.WriteLine("==================================================");
                        index++;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка: {ex.Message}");
            }
            Console.ReadKey();
        }
    }
}
