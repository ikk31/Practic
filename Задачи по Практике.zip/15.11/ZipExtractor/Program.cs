﻿using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;

class ZipExtractor
{
    static void Main(string[] args)
    {
        Console.WriteLine("=== ZIP Archive Manager ===");

        while (true)
        {
            Console.WriteLine("\nВыберите действие:");
            Console.WriteLine("1 - Извлечь файлы из архива");
            Console.WriteLine("2 - Создать архив из папки");
            Console.WriteLine("3 - Выход");
            Console.Write("Ваш выбор: ");

            string choice = Console.ReadLine();

            switch (choice)
            {
                case "1":
                    ExtractFromArchive();
                    break;
                case "2":
                    CreateArchive();
                    break;
                case "3":
                    Console.WriteLine("До свидания!");
                    return;
                default:
                    Console.WriteLine("Неверный выбор. Попробуйте снова.");
                    break;
            }
        }
    }

    static void ExtractFromArchive()
    {
        try
        {
            // 1. Запрос пути к архиву
            Console.Write("Введите путь к ZIP-архиву: ");
            string archivePath = Console.ReadLine();

            if (!File.Exists(archivePath))
            {
                Console.WriteLine("Ошибка: Архив не найден!");
                return;
            }

            // 2. Открытие архива и показ списка файлов
            using (var archive = ZipFile.OpenRead(archivePath))
            {
                if (!archive.Entries.Any())
                {
                    Console.WriteLine("Архив пуст!");
                    return;
                }

                // Показ информации об архиве
                ShowArchiveInfo(archive);

                // 3. Выбор действия
                Console.WriteLine("\nВыберите действие:");
                Console.WriteLine("1 - Извлечь все файлы");
                Console.WriteLine("2 - Извлечь выбранный файл по номеру");
                Console.WriteLine("3 - Извлечь файлы по расширению");
                Console.Write("Ваш выбор: ");

                string action = Console.ReadLine();

                switch (action)
                {
                    case "1":
                        ExtractAllFiles(archive);
                        break;
                    case "2":
                        ExtractSelectedFile(archive);
                        break;
                    case "3":
                        ExtractByExtension(archive);
                        break;
                    default:
                        Console.WriteLine("Неверный выбор!");
                        break;
                }
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Ошибка: {ex.Message}");
        }
    }

    static void ShowArchiveInfo(ZipArchive archive)
    {
        Console.WriteLine($"\nСодержимое архива ({archive.Entries.Count} файлов):");
        Console.WriteLine(new string('-', 60));
        Console.WriteLine("№  | Размер  | Имя файла");
        Console.WriteLine(new string('-', 60));

        long totalSize = 0;
        int index = 1;

        foreach (var entry in archive.Entries)
        {
            // Пропускаем папки (они имеют пустое имя или заканчиваются на /)
            if (string.IsNullOrEmpty(entry.Name) || entry.FullName.EndsWith("/"))
                continue;

            long size = entry.Length;
            totalSize += size;
            Console.WriteLine($"{index,-2} | {FormatFileSize(size),-7} | {entry.FullName}");
            index++;
        }

        Console.WriteLine(new string('-', 60));
        Console.WriteLine($"Общий размер: {FormatFileSize(totalSize)}");
    }

    static void ExtractAllFiles(ZipArchive archive)
    {
        Console.Write("Введите путь для извлечения: ");
        string extractPath = Console.ReadLine();

        if (!Directory.Exists(extractPath))
        {
            Console.Write("Папка не существует. Создать? (y/n): ");
            if (Console.ReadLine().ToLower() == "y")
            {
                Directory.CreateDirectory(extractPath);
            }
            else
            {
                return;
            }
        }

        int extractedCount = 0;
        int skippedCount = 0;

        foreach (var entry in archive.Entries)
        {
            // Пропускаем папки
            if (string.IsNullOrEmpty(entry.Name))
                continue;

            string destinationPath = Path.Combine(extractPath, entry.FullName);
            string destinationDir = Path.GetDirectoryName(destinationPath);

            // Создаем папки если нужно
            if (!Directory.Exists(destinationDir))
                Directory.CreateDirectory(destinationDir);

            // Проверяем существование файла
            if (File.Exists(destinationPath))
            {
                Console.Write($"Файл {entry.FullName} уже существует. Перезаписать? (y/n): ");
                if (Console.ReadLine().ToLower() != "y")
                {
                    skippedCount++;
                    continue;
                }
            }

            try
            {
                entry.ExtractToFile(destinationPath, overwrite: true);
                Console.WriteLine($"Извлечен: {entry.FullName}");
                extractedCount++;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка при извлечении {entry.FullName}: {ex.Message}");
            }
        }

        Console.WriteLine($"\nИзвлечение завершено: {extractedCount} файлов извлечено, {skippedCount} пропущено.");
    }

    static void ExtractSelectedFile(ZipArchive archive)
    {
        var files = archive.Entries.Where(e => !string.IsNullOrEmpty(e.Name)).ToList();

        if (!files.Any())
        {
            Console.WriteLine("В архиве нет файлов для извлечения!");
            return;
        }

        Console.Write("Введите номер файла для извлечения: ");
        if (!int.TryParse(Console.ReadLine(), out int fileNumber) || fileNumber < 1 || fileNumber > files.Count)
        {
            Console.WriteLine("Неверный номер файла!");
            return;
        }

        var selectedFile = files[fileNumber - 1];
        Console.Write("Введите путь для извлечения: ");
        string extractPath = Console.ReadLine();

        if (!Directory.Exists(extractPath))
        {
            Console.Write("Папка не существует. Создать? (y/n): ");
            if (Console.ReadLine().ToLower() == "y")
            {
                Directory.CreateDirectory(extractPath);
            }
            else
            {
                return;
            }
        }

        string destinationPath = Path.Combine(extractPath, selectedFile.Name);

        if (File.Exists(destinationPath))
        {
            Console.Write($"Файл {selectedFile.Name} уже существует. Перезаписать? (y/n): ");
            if (Console.ReadLine().ToLower() != "y")
            {
                Console.WriteLine("Извлечение отменено.");
                return;
            }
        }

        try
        {
            selectedFile.ExtractToFile(destinationPath, overwrite: true);
            Console.WriteLine($"Файл успешно извлечен: {destinationPath}");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Ошибка при извлечении: {ex.Message}");
        }
    }

    static void ExtractByExtension(ZipArchive archive)
    {
        Console.Write("Введите расширение файлов (например: txt, jpg, png): ");
        string extension = Console.ReadLine().TrimStart('.').ToLower();

        var matchingFiles = archive.Entries
            .Where(e => !string.IsNullOrEmpty(e.Name) &&
                       Path.GetExtension(e.Name).TrimStart('.').ToLower() == extension)
            .ToList();

        if (!matchingFiles.Any())
        {
            Console.WriteLine($"Файлы с расширением .{extension} не найдены!");
            return;
        }

        Console.WriteLine($"\nНайдено {matchingFiles.Count} файлов с расширением .{extension}:");
        foreach (var file in matchingFiles)
        {
            Console.WriteLine($"  - {file.FullName}");
        }

        Console.Write("Извлечь эти файлы? (y/n): ");
        if (Console.ReadLine().ToLower() != "y")
            return;

        Console.Write("Введите путь для извлечения: ");
        string extractPath = Console.ReadLine();

        if (!Directory.Exists(extractPath))
        {
            Console.Write("Папка не существует. Создать? (y/n): ");
            if (Console.ReadLine().ToLower() == "y")
            {
                Directory.CreateDirectory(extractPath);
            }
            else
            {
                return;
            }
        }

        int extractedCount = 0;
        foreach (var file in matchingFiles)
        {
            string destinationPath = Path.Combine(extractPath, file.Name);

            if (File.Exists(destinationPath))
            {
                Console.Write($"Файл {file.Name} уже существует. Перезаписать? (y/n): ");
                if (Console.ReadLine().ToLower() != "y")
                    continue;
            }

            try
            {
                file.ExtractToFile(destinationPath, overwrite: true);
                Console.WriteLine($"Извлечен: {file.Name}");
                extractedCount++;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка при извлечении {file.Name}: {ex.Message}");
            }
        }

        Console.WriteLine($"Извлечено {extractedCount} файлов.");
    }

    static void CreateArchive()
    {
        try
        {
            Console.Write("Введите путь к папке для архивации: ");
            string sourceFolder = Console.ReadLine();

            if (!Directory.Exists(sourceFolder))
            {
                Console.WriteLine("Папка не существует!");
                return;
            }

            Console.Write("Введите путь для сохранения ZIP-архива: ");
            string archivePath = Console.ReadLine();

            // Добавляем расширение .zip если его нет
            if (!Path.HasExtension(archivePath) || Path.GetExtension(archivePath).ToLower() != ".zip")
            {
                archivePath = Path.Combine(Path.GetDirectoryName(archivePath),
                                         Path.GetFileNameWithoutExtension(archivePath) + ".zip");
            }

            // Проверяем существование архива
            if (File.Exists(archivePath))
            {
                Console.Write("Архив уже существует. Перезаписать? (y/n): ");
                if (Console.ReadLine().ToLower() != "y")
                {
                    return;
                }
                File.Delete(archivePath);
            }

            // Создаем архив
            ZipFile.CreateFromDirectory(sourceFolder, archivePath, CompressionLevel.Optimal, includeBaseDirectory: false);
            Console.WriteLine($"Архив успешно создан: {archivePath}");

            // Показываем информацию о созданном архиве
            using (var archive = ZipFile.OpenRead(archivePath))
            {
                Console.WriteLine($"Файлов в архиве: {archive.Entries.Count(e => !string.IsNullOrEmpty(e.Name))}");
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Ошибка при создании архива: {ex.Message}");
        }
    }

    static string FormatFileSize(long bytes)
    {
        string[] sizes = { "B", "KB", "MB", "GB" };
        int order = 0;
        double len = bytes;
        while (len >= 1024 && order < sizes.Length - 1)
        {
            order++;
            len /= 1024;
        }
        return $"{len:0.##} {sizes[order]}";
    }
}