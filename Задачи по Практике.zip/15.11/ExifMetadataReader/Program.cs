﻿using System;
using System.IO;

class SimpleImageInfo
{
    static void Main(string[] args)
    {
        Console.WriteLine("Введите путь к файлу изображения:");
        string filePath = Console.ReadLine();

        try
        {
            ShowBasicImageInfo(filePath);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Ошибка: {ex.Message}");
        }

        Console.WriteLine("\nНажмите любую клавишу для выхода...");
        Console.ReadKey();
    }

    static void ShowBasicImageInfo(string filePath)
    {
        if (!File.Exists(filePath))
        {
            Console.WriteLine("Файл не найден!");
            return;
        }

        FileInfo fileInfo = new FileInfo(filePath);
        Console.WriteLine($"Файл: {fileInfo.Name}");
        Console.WriteLine($"Размер файла: {fileInfo.Length} байт");
        Console.WriteLine($"Дата создания: {fileInfo.CreationTime}");
        Console.WriteLine($"Дата изменения: {fileInfo.LastWriteTime}");

        // Для получения разрешения и EXIF в этом случае потребуется
        // дополнительная библиотека или более сложная реализация
        Console.WriteLine("EXIF-данные: Для полного чтения EXIF установите System.Drawing.Common");
    }
}