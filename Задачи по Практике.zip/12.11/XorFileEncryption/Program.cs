﻿using System;
using System.IO;
using System.Text;

class XorFileEncryption
{
    static void Main()
    {
        Console.WriteLine("=== XOR Шифрование/Дешифрование файлов ===");

        try
        {
            // Запрос пути к файлу
            Console.Write("Введите путь к файлу: ");
            string filePath = Console.ReadLine()?.Trim('"').Trim();

            if (string.IsNullOrEmpty(filePath) || !File.Exists(filePath))
            {
                Console.WriteLine("Ошибка: Файл не существует или путь указан неверно.");
                return;
            }

            // Запрос ключа
            Console.Write("Введите ключ: ");
            string key = Console.ReadLine();

            if (string.IsNullOrEmpty(key))
            {
                Console.WriteLine("Ошибка: Ключ не может быть пустым.");
                return;
            }

            // Шифрование/дешифрование
            string resultFile = ProcessFile(filePath, key);

            Console.WriteLine($"Готово. Результат: {resultFile}");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Произошла ошибка: {ex.Message}");
        }

        Console.WriteLine("Нажмите любую клавишу для выхода...");
        Console.ReadKey();
    }

    static string ProcessFile(string inputFilePath, string key)
    {
        string outputFilePath = inputFilePath + ".xor";
        byte[] keyBytes = Encoding.UTF8.GetBytes(key);

        using (FileStream inputStream = File.OpenRead(inputFilePath))
        using (FileStream outputStream = File.Create(outputFilePath))
        {
            byte[] buffer = new byte[4096];
            int bytesRead;
            int keyIndex = 0;

            while ((bytesRead = inputStream.Read(buffer, 0, buffer.Length)) > 0)
            {
                // Применяем XOR к каждому байту
                for (int i = 0; i < bytesRead; i++)
                {
                    buffer[i] = (byte)(buffer[i] ^ keyBytes[keyIndex]);
                    keyIndex = (keyIndex + 1) % keyBytes.Length;
                }

                outputStream.Write(buffer, 0, bytesRead);
            }
        }

        return outputFilePath;
    }
}