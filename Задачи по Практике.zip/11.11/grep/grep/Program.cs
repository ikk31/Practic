﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace grep
{
    internal class Program
    {
       
        static void Grep(string path, string input)
        {
            string resultPath = @"C:\Users\mihal\Desktop\result.txt";
            string[] result;
            Console.WriteLine("Результат поиска:");
            foreach (string line in File.ReadAllLines(path)) 
            {
                if (line.Contains(input)) 
                {
                    Console.WriteLine(line);
                }
            }
        }

        static void ls(string path)
        {
            string[] fileNames = Directory.GetFiles(path);
            foreach (string lines in fileNames)
            {
                Console.WriteLine($"{lines}");
            }
        }

        static string cd(string command)
        {
            if (command == "cd ..")
            {
                return @"C:\Users\mihal\";
            }
            string word = command.Remove(0, 3);
            return @"C:\Users\mihal\" + word;
        }


      
        static void Main(string[] args)
        {
            
            Console.WriteLine("Введите команду");
            string command;
            string path1;
            //while (true)
            //    {
                command = Console.ReadLine();
                path1 = cd(command) + @"\";
                cd(command);
                ls(path1);
                //}
            
            Console.WriteLine("Напишите название файла: ");
            string input = Console.ReadLine();
            Console.WriteLine("Введите слово для поиска");
            string find = Console.ReadLine();
            Grep(path1 + input, find);
            Console.ReadKey();
        }
    }
}
