﻿namespace Razmika3
{
    public struct Game
    {
        public string Name;
        public string Genre;
        public string Developer;
        public double Rating;

        public void Display()
        {
            Console.WriteLine($"Название: {Name}");
            Console.WriteLine($"Жанр: {Genre}");
            Console.WriteLine($"Разработчик: {Developer}");
            Console.WriteLine($"Рейтинг: {Rating:F1}");
            Console.WriteLine(new string('-', 30));
        }
    }
    internal class Program
    {
        private const string FilePath = @"C:\Users\mihal\Desktop\games.txt";
        static void Main(string[] args)
        {
            Console.WriteLine("=== КАТАЛОГ КОМПЬЮТЕРНЫХ ИГР ===");

            while (true)
            {
                ShowMenu();
                string choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        AddGame();
                        break;
                    case "2":
                        ShowGamesByGenre();
                        break;
                    case "3":
                        ShowGamesByDeveloper();
                        break;
                    case "4":
                        ShowAllGames();
                        break;
                    case "5":
                        Console.WriteLine("Выход из программы...");
                        return;
                    default:
                        Console.WriteLine("Неверный выбор! Попробуйте снова.");
                        break;
                }

                Console.WriteLine("\nНажмите любую клавишу для продолжения...");
                Console.ReadKey();
                Console.Clear();
            }
        }

        static void ShowMenu()
        {
            Console.WriteLine("\nМЕНЮ:");
            Console.WriteLine("1 - Добавить игру");
            Console.WriteLine("2 - Показать игры по жанру");
            Console.WriteLine("3 - Показать игры по разработчику");
            Console.WriteLine("4 - Показать все игры");
            Console.WriteLine("5 - Выход");
            Console.Write("Выберите действие: ");
        }

        static void AddGame()
        {
            Console.WriteLine("\n=== ДОБАВЛЕНИЕ НОВОЙ ИГРЫ ===");

            Game game = new Game();

            Console.Write("Введите название игры: ");
            game.Name = Console.ReadLine();

            Console.Write("Введите жанр: ");
            game.Genre = Console.ReadLine();

            Console.Write("Введите разработчика: ");
            game.Developer = Console.ReadLine();

            Console.Write("Введите рейтинг (0.0-10.0): ");
            if (double.TryParse(Console.ReadLine(), out double rating))
            {
                game.Rating = Math.Max(0, Math.Min(10, rating));
            }
            else
            {
                Console.WriteLine("Неверный формат рейтинга! Установлен 0.0");
                game.Rating = 0.0;
            }

            try
            {
                using (StreamWriter writer = new StreamWriter(FilePath, true))
                {
                    writer.WriteLine($"Name: {game.Name}");
                    writer.WriteLine($"Genre: {game.Genre}");
                    writer.WriteLine($"Developer: {game.Developer}");
                    writer.WriteLine($"Rating: {game.Rating:F1}");
                    writer.WriteLine();
                }
                Console.WriteLine($"\nИгра \"{game.Name}\" успешно добавлена в каталог!");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка при сохранении: {ex.Message}");
            }
        }

        static List<Game> ReadAllGames()
        {
            List<Game> games = new List<Game>();

            if (!File.Exists(FilePath))
            {
                return games;
            }

            try
            {
                string[] lines = File.ReadAllLines(FilePath);
                Game currentGame = new Game();
                bool readingGame = false;

                foreach (string line in lines)
                {
                    if (line.StartsWith("Name: "))
                    {
                        if (readingGame)
                        {
                            games.Add(currentGame);
                        }
                        currentGame = new Game();
                        currentGame.Name = line.Substring(6);
                        readingGame = true;
                    }
                    else if (line.StartsWith("Genre: "))
                    {
                        currentGame.Genre = line.Substring(7);
                    }
                    else if (line.StartsWith("Developer: "))
                    {
                        currentGame.Developer = line.Substring(11);
                    }
                    else if (line.StartsWith("Rating: "))
                    {
                        if (double.TryParse(line.Substring(8), out double rating))
                        {
                            currentGame.Rating = rating;
                        }
                    }
                    else if (string.IsNullOrWhiteSpace(line) && readingGame)
                    {
                        games.Add(currentGame);
                        readingGame = false;
                    }
                }

                if (readingGame)
                {
                    games.Add(currentGame);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка при чтении файла: {ex.Message}");
            }

            return games;
        }

        static void ShowGamesByGenre()
        {
            Console.WriteLine("\n=== ПОИСК ПО ЖАНРУ ===");

            List<Game> allGames = ReadAllGames();
            if (allGames.Count == 0)
            {
                Console.WriteLine("Каталог пуст. Добавьте игры!");
                return;
            }

            var availableGenres = allGames.Select(g => g.Genre).Distinct().OrderBy(g => g);
            Console.WriteLine("Доступные жанры: " + string.Join(", ", availableGenres));

            Console.Write("Введите жанр для поиска: ");
            string genre = Console.ReadLine();

            var filteredGames = allGames
                .Where(g => g.Genre.Equals(genre, StringComparison.OrdinalIgnoreCase))
                .OrderByDescending(g => g.Rating)
                .ToList();

            if (filteredGames.Count > 0)
            {
                Console.WriteLine($"\nНайдено игр в жанре '{genre}': {filteredGames.Count}");
                foreach (var game in filteredGames)
                {
                    game.Display();
                }
            }
            else
            {
                Console.WriteLine($"Игр в жанре '{genre}' не найдено.");
            }
        }

        static void ShowGamesByDeveloper()
        {
            Console.WriteLine("\n=== ПОИСК ПО РАЗРАБОТЧИКУ ===");

            List<Game> allGames = ReadAllGames();
            if (allGames.Count == 0)
            {
                Console.WriteLine("Каталог пуст. Добавьте игры!");
                return;
            }

            var availableDevelopers = allGames.Select(g => g.Developer).Distinct().OrderBy(g => g);
            Console.WriteLine("Доступные разработчики: " + string.Join(", ", availableDevelopers));

            Console.Write("Введите разработчика для поиска: ");
            string developer = Console.ReadLine();

            var filteredGames = allGames
                .Where(g => g.Developer.Equals(developer, StringComparison.OrdinalIgnoreCase))
                .OrderByDescending(g => g.Rating)
                .ToList();

            if (filteredGames.Count > 0)
            {
                Console.WriteLine($"\nНайдено игр от разработчика '{developer}': {filteredGames.Count}");
                foreach (var game in filteredGames)
                {
                    game.Display();
                }
            }
            else
            {
                Console.WriteLine($"Игр от разработчика '{developer}' не найдено.");
            }
        }

        static void ShowAllGames()
        {
            Console.WriteLine("\n=== ВСЕ ИГРЫ В КАТАЛОГЕ ===");

            List<Game> allGames = ReadAllGames();

            if (allGames.Count > 0)
            {
                Console.WriteLine($"Всего игр в каталоге: {allGames.Count}\n");

                var sortedGames = allGames.OrderByDescending(g => g.Rating);

                foreach (var game in sortedGames)
                {
                    game.Display();
                }
                ShowStatistics(allGames);
            }
            else
            {
                Console.WriteLine("Каталог пуст. Добавьте игры!");
            }
        }

        static void ShowStatistics(List<Game> games)
        {
            if (games.Count > 0)
            {
                Console.WriteLine("\n=== СТАТИСТИКА ===");
                Console.WriteLine($"Средний рейтинг всех игр: {games.Average(g => g.Rating):F1}");

                var topGames = games.OrderByDescending(g => g.Rating).Take(3);
                Console.WriteLine("\nТоп-3 игр по рейтингу:");
                foreach (var game in topGames)
                {
                    Console.WriteLine($"- {game.Name} ({game.Rating:F1}) - {game.Developer}");
                }

                var genres = games.GroupBy(g => g.Genre).OrderByDescending(g => g.Count());
                Console.WriteLine("\nКоличество игр по жанрам:");
                foreach (var genre in genres)
                {
                    Console.WriteLine($"- {genre.Key}: {genre.Count()} игр");
                }

                var developers = games.GroupBy(g => g.Developer).OrderByDescending(g => g.Count());
                Console.WriteLine("\nКоличество игр по разработчикам:");
                foreach (var developer in developers)
                {
                    Console.WriteLine($"- {developer.Key}: {developer.Count()} игр");
                }
            }
        }
    }
    }

