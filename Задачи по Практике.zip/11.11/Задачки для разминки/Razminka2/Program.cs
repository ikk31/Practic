﻿namespace Razminka2
{
    public struct Student
    {
        public string Name;
        public string Group;
        public int Grade;

        public override string ToString()
        {
            return $"Студент: {Name}, Группа: {Group}, Оценка: {Grade}";
        }
    }
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Система учёта оценок студентов");

            while (true)
            {
                Console.WriteLine("\nВыберите действие:");
                Console.WriteLine("1. Добавить новых студентов");
                Console.WriteLine("2. Показать студентов с оценкой выше 8");
                Console.WriteLine("3. Показать средний балл по группам");
                Console.WriteLine("4. Показать всех студентов");
                Console.WriteLine("5. Выход");
                Console.Write("Ваш выбор: ");

                string choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        AddNewStudents();
                        break;
                    case "2":
                        ShowStudentsAboveGrade(8);
                        break;
                    case "3":
                        ShowGroupAverages();
                        break;
                    case "4":
                        ShowAllStudents();
                        break;
                    case "5":
                        Console.WriteLine("Программа завершена.");
                        return;
                    default:
                        Console.WriteLine("Некорректный выбор. Попробуйте снова.");
                        break;
                }
            }
        }

        static void AddNewStudents()
        {
            List<Student> students = new List<Student>();

            Console.WriteLine("\nВведите данные о студентах (для завершения введите 'exit' в имени):");

            int studentCount = 0;
            while (true)
            {
                studentCount++;
                Console.WriteLine($"\nСтудент {studentCount}:");

                Student student = new Student();

                Console.Write("Имя: ");
                student.Name = Console.ReadLine();

                if (student.Name.ToLower() == "exit")
                    break;

                if (string.IsNullOrWhiteSpace(student.Name))
                {
                    Console.WriteLine("Имя не может быть пустым!");
                    studentCount--;
                    continue;
                }

                Console.Write("Группа: ");
                student.Group = Console.ReadLine();

                if (string.IsNullOrWhiteSpace(student.Group))
                {
                    Console.WriteLine("Группа не может быть пустой!");
                    studentCount--;
                    continue;
                }

                Console.Write("Оценка (1-10): ");
                while (!int.TryParse(Console.ReadLine(), out student.Grade) || student.Grade < 1 || student.Grade > 10)
                {
                    Console.Write("Введите корректную оценку (1-10): ");
                }

                students.Add(student);
                Console.WriteLine("Студент добавлен!");
            }

            if (students.Count > 0)
            {
                SaveStudentsToFile(students, "grades.txt", true);
                Console.WriteLine($"\nУспешно добавлено {students.Count} студентов в файл grades.txt");
            }
            else
            {
                Console.WriteLine("\nНе было добавлено ни одного студента.");
            }
        }

        static void ShowStudentsAboveGrade(int minGrade)
        {
            List<Student> students = ReadStudentsFromFile(@"C:\Users\mihal\Desktop\grades.txt");

            if (students.Count == 0)
            {
                Console.WriteLine("Файл со студентами не найден или пуст.");
                return;
            }

            var filteredStudents = students.Where(s => s.Grade > minGrade).ToList();

            Console.WriteLine($"\nСтуденты с оценкой выше {minGrade}:");
            Console.WriteLine("=================================");

            if (filteredStudents.Count > 0)
            {
                foreach (var student in filteredStudents)
                {
                    Console.WriteLine(student);
                }
                Console.WriteLine($"\nВсего найдено: {filteredStudents.Count} студент(ов)");
            }
            else
            {
                Console.WriteLine("Студентов с такой оценкой не найдено.");
            }
        }

        static void ShowGroupAverages()
        {
            List<Student> students = ReadStudentsFromFile(@"C:\Users\mihal\Desktop1\grades.txt");

            if (students.Count == 0)
            {
                Console.WriteLine("Файл со студентами не найден или пуст.");
                return;
            }

            var groupAverages = students
                .GroupBy(s => s.Group)
                .Select(g => new
                {
                    Group = g.Key,
                    AverageGrade = Math.Round(g.Average(s => s.Grade), 2),
                    StudentCount = g.Count()
                })
                .OrderBy(g => g.Group)
                .ToList();

            Console.WriteLine("\nСредний балл по группам:");
            Console.WriteLine("========================");

            foreach (var group in groupAverages)
            {
                Console.WriteLine($"Группа {group.Group}: средний балл {group.AverageGrade} ({group.StudentCount} студентов)");
            }

            // Общий средний балл
            double overallAverage = Math.Round(students.Average(s => s.Grade), 2);
            Console.WriteLine($"\nОбщий средний балл: {overallAverage}");
        }

        static void ShowAllStudents()
        {
            List<Student> students = ReadStudentsFromFile(@"C:\Users\mihal\Desktop\grades.txt");

            if (students.Count == 0)
            {
                Console.WriteLine("Файл со студентами не найден или пуст.");
                return;
            }

            Console.WriteLine("\nВсе студенты:");
            Console.WriteLine("==============");

            // Группируем по группам для удобного отображения
            var groupedStudents = students
                .GroupBy(s => s.Group)
                .OrderBy(g => g.Key);

            foreach (var group in groupedStudents)
            {
                Console.WriteLine($"\nГруппа {group.Key}:");
                foreach (var student in group.OrderBy(s => s.Name))
                {
                    Console.WriteLine($"  {student.Name} - {student.Grade}");
                }
            }

            Console.WriteLine($"\nВсего студентов: {students.Count}");
        }

        // Метод для сохранения студентов в файл
        static void SaveStudentsToFile(List<Student> students, string filename, bool append = true)
        {
            using (StreamWriter writer = new StreamWriter(filename, append))
            {
                foreach (Student student in students)
                {
                    writer.WriteLine($"Name: {student.Name}");
                    writer.WriteLine($"Group: {student.Group}");
                    writer.WriteLine($"Grade: {student.Grade}");
                    writer.WriteLine(); // Пустая строка между студентами
                }
            }
        }

        // Метод для чтения студентов из файла
        static List<Student> ReadStudentsFromFile(string filename)
        {
            List<Student> students = new List<Student>();

            if (!File.Exists(filename))
                return students;

            using (StreamReader reader = new StreamReader(filename))
            {
                Student currentStudent = new Student();
                string line;

                while ((line = reader.ReadLine()) != null)
                {
                    if (string.IsNullOrWhiteSpace(line))
                    {
                        // Пустая строка означает конец записи о студенте
                        if (!string.IsNullOrEmpty(currentStudent.Name))
                        {
                            students.Add(currentStudent);
                            currentStudent = new Student();
                        }
                        continue;
                    }

                    if (line.StartsWith("Name:"))
                    {
                        currentStudent.Name = line.Substring(6).Trim();
                    }
                    else if (line.StartsWith("Group:"))
                    {
                        currentStudent.Group = line.Substring(7).Trim();
                    }
                    else if (line.StartsWith("Grade:"))
                    {
                        if (int.TryParse(line.Substring(7).Trim(), out int grade))
                        {
                            currentStudent.Grade = grade;
                        }
                    }
                }

                // Добавляем последнего студента, если файл не заканчивается пустой строкой
                if (!string.IsNullOrEmpty(currentStudent.Name))
                {
                    students.Add(currentStudent);
                }
            }

            return students;
        }
    }
}
