﻿namespace Razminka1
{
    public struct Book
    {
        public string Title;
        public string Author;
        public int Year;
        public decimal Price;

        public override string ToString()
        {
            return $"Название: {Title}, Автор: {Author}, Год: {Year}, Цена: {Price}";
        }
    }
    internal class Program
    {

        static void Main(string[] args)
        {
            string path = @"C:\Users\mihal\Desktop\books.txt";
            Console.WriteLine("Программа для работы с книгами");
            Console.WriteLine("1. Добавить новые книги (данные добавятся в конец файла)");
            Console.WriteLine("2. Показать книги старше указанного года");
            Console.Write("Выберите действие (1 или 2): ");

            string choice = Console.ReadLine();

            if (choice == "1")
            {
                AddNewBooks();
            }
            else if (choice == "2")
            {
                FilterBooksByYear();
            }
            else
            {
                Console.WriteLine("Некорректный выбор.");
            }
            Console.ReadKey();
        }

        // добавление в файл
        static void AddNewBooks()
        {
            string path = @"D:\Папка Вани\Колледж\2025-2026 уч. год\УП.01.01\11.11\books.txt";
            List<Book> books = new List<Book>();

            Console.WriteLine("\nВведите данные о книгах (для завершения введите 'exit' в названии):");

            int bookCount = 0;
            for (int i = 0; i < 5; i++)
            {
                bookCount++;
                Console.WriteLine($"\nКнига {bookCount}:");

                Book book = new Book();

                Console.Write("Название: ");
                book.Title = Console.ReadLine();

                if (book.Title.ToLower() == "exit")
                    break;

                if (string.IsNullOrWhiteSpace(book.Title))
                {
                    Console.WriteLine("Название не может быть пустым!");
                    bookCount--;
                    continue;
                }

                Console.Write("Автор: ");
                book.Author = Console.ReadLine();

                if (string.IsNullOrWhiteSpace(book.Author))
                {
                    Console.WriteLine("Автор не может быть пустым!");
                    bookCount--;
                    continue;
                }

                Console.Write("Год издания: ");
                while (!int.TryParse(Console.ReadLine(), out book.Year) || book.Year < 0 || book.Year > DateTime.Now.Year)
                {
                    Console.Write("Введите корректный год: ");
                }

                Console.Write("Цена: ");
                while (!decimal.TryParse(Console.ReadLine(), out book.Price) || book.Price < 0)
                {
                    Console.Write("Введите корректную цену: ");
                }

                books.Add(book);
                Console.WriteLine("Книга добавлена!");
            }
            SaveBooksToFile(books, path, true);
            Console.WriteLine($"\nУспешно добавлено {books.Count} книг в файл books.txt");
        }

        static void FilterBooksByYear()
        {
            string path = @"C:\Users\mihal\Desktop\books.txt";
            Console.Write("\nВведите год для фильтрации (будут показаны книги старше этого года): ");
            if (int.TryParse(Console.ReadLine(), out int filterYear))
            {
                DisplayBooks(path, filterYear);
            }
            else
            {
                Console.WriteLine("Некорректный год для фильтрации.");
            }
        }

        // сохранение
        static void SaveBooksToFile(List<Book> books, string filename, bool append = true)
        {
            using (StreamWriter writer = new StreamWriter(filename, append))
            {
                foreach (Book book in books)
                {
                    writer.WriteLine($"Title: {book.Title}");
                    writer.WriteLine($"Author: {book.Author}");
                    writer.WriteLine($"Year: {book.Year}");
                    writer.WriteLine($"Price: {book.Price}");
                    writer.WriteLine();
                }
            }
        }

        // чтение файла и вывод в консоль
        static void DisplayBooks(string filename, int year)
        {
            List<Book> booksFromFile = new List<Book>();

            using (StreamReader reader = new StreamReader(filename))
            {
                Book currentBook = new Book();
                string line;

                while ((line = reader.ReadLine()) != null)
                {
                    if (string.IsNullOrWhiteSpace(line))
                    {
                        if (!string.IsNullOrEmpty(currentBook.Title))
                        {
                            booksFromFile.Add(currentBook);
                            currentBook = new Book();
                        }
                        continue;
                    }

                    if (line.StartsWith("Title:"))
                    {
                        currentBook.Title = line.Substring(7).Trim();
                    }
                    else if (line.StartsWith("Author:"))
                    {
                        currentBook.Author = line.Substring(8).Trim();
                    }
                    else if (line.StartsWith("Year:"))
                    {
                        if (int.TryParse(line.Substring(6).Trim(), out int bookYear))
                        {
                            currentBook.Year = bookYear;
                        }
                    }
                    else if (line.StartsWith("Price:"))
                    {
                        if (decimal.TryParse(line.Substring(7).Trim(), out decimal bookPrice))
                        {
                            currentBook.Price = bookPrice;
                        }
                    }
                }

                if (!string.IsNullOrEmpty(currentBook.Title))
                {
                    booksFromFile.Add(currentBook);
                }
            }

            Console.WriteLine($"\nКниги старше {year} года:");
            bool found = false;

            foreach (Book book in booksFromFile)
            {
                if (book.Year > year)
                {
                    Console.WriteLine(book);
                    found = true;
                }
            }

            if (!found)
            {
                Console.WriteLine("Книг старше указанного года не найдено.");
            }
        }
    }
    }

